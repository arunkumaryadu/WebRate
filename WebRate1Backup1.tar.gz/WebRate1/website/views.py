from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
from .models import website
def web_detail(request):
    w1=website.objects.all()
    return render(request,'website/home.html',{'w1':w1})

def webView(request,web_id):
    w2=website.objects.filter(id=web_id)
    return render(request,'website/webView.html',{'w2':w2})
    #return HttpResponse("<h1> welcome in id :" +w1+ "</h1>")
