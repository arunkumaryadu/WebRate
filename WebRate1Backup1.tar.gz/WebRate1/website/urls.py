from django.urls import include, path
from website import views
from django.conf.urls.static import static
from django.conf import settings
from django.conf.urls import url



urlpatterns = [

    path('', views.web_detail, name='home1'),
    path('webView/', views.webView, name='webView'),
    url(r'^(?P<web_id>[0-9]+)/$',views.webView),



]+static(settings.STATIC_URL,document_root=settings.STATIC_DIR)
