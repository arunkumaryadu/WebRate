from django.contrib import admin
from website.models import website

# Register your models here.
admin.site.register(website)
