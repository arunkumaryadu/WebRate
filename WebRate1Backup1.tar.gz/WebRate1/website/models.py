from django.db import models
#from django.contrib.admin.widgets import AdminDateWidget
#from django import forms
#from django.forms.fields import DateField
from datetime import datetime

# Create your models here.
Cat_choices=(
('COLLEGE','college'),
('SHOPING','shoping'),
('SPORTS','sports'),
)
class website(models.Model):
    website_name=models.CharField(max_length=50)
    website_url=models.CharField(max_length=100)
    website_category=models.CharField(max_length=100,choices=Cat_choices)
    website_description=models.CharField(max_length=200)
    Web_update_date=models.DateField(null=True)
    website_logo=models.FileField(upload_to='static/uploads/')
    website_image=models.FileField(upload_to='static/uploads/')
    def __str__(self):
        return self.website_name
